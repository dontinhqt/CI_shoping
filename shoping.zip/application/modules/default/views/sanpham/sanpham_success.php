<div class="span9">
  <div class="title-widget">
    <div class="row-fluid heading-content">
      <div class="span12">
        <h4 class="title"><span>Chi tiết sản phẩm</span></h4>
      </div>
    </div>
  </div>

  <div class="table-responsive">
    <p style="text-align:center;">
      <div id="ss"class="style_backgroud">

        <h3>Cảm ơn bạn đã gửi thông tin đặt mua hàng cho chúng tôi. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất.</h3>
        <?php if($error != "")
        {
          echo "<span style='color:red; font-size:20px;'>".$error."</span>";
        }?>
        <h3><a href="<?php echo base_url(); ?>">Về trang chủ.</a></h3>
        </div>
    </p>
  </div>
</div>
